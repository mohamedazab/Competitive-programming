package Strings;

public class permutation {

	public static void main(String[] args) {

	}

}
