package Geometry;

public class linesweap {

}
