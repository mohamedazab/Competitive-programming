
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.TreeMap;

public class Main {

    static int n,m;

    static int mem[][];
    static TreeMap<Integer,monster> map;
    static String LIS_EFF(){
        int parent[]=new int[n],seq[]=new int[n+1]//track end of each inc subseq
                ,length=0;

        for (int i = 0; i < n; i++) {

            int low=1;
            int high=length;
            //binarysearch
            //find element to replace
            while(low<=high)
            {
                int mid=(int)Math.ceil((low+high)/2);

                if(map.get(seq[mid]).compareTo(map.get(i))!=1)
                    low=mid+1;
                else
                    high=mid-1;

            }



            int pos=low;
            parent[i]=seq[pos-1];//update parent
            seq[pos]=i;
            length=length<pos?pos:length;





        }
        //print LIS
        String s="";
        int last=seq[length];
        for (int j = length-1; j >=0; j--) {
            s=(last+1)+" "+s;
            last=parent[last];
        }
        //System.out.println(length);
       return s.substring(0,s.length()-1);

    }


    public static void main(String[] args)throws Exception {
        Scanner sc=new Scanner(System.in);
        PrintWriter out=new PrintWriter(System.out);
        m=sc.nextInt();
        n=sc.nextInt();
        map=new TreeMap<>();
        for (int i = 0; i <n ; i++) {
            map.put(i,new monster(m));
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j <n ; j++) {
               monster k=map.get(j);
               k.attr.add(sc.nextInt());

            }
        }

       out.println(LIS_EFF());








        out.flush();
        out.close();



    }

    static class monster implements Comparable<monster>{
        ArrayList<Integer>attr;
        int m;
        public monster(int m ){
            this.m=m;
            attr=new ArrayList<>(m);
        }
        @Override
        public int compareTo( monster o) {
           boolean gr=true;//me>o
            for (int i = 0; i <m ; i++) {
              if(attr.get(i)<=o.attr.get(i))
              {
                  gr=false;break;
              }
            }
            if (gr)return 1;

            boolean less=true;
            for (int i = 0; i <m ; i++) {
                if(o.attr.get(i)<=attr.get(i))
                {
                    less=false;break;
                }
            }
            if(less)return -1;


             return -1;
        }

        @Override
        public String toString() {
            return attr.toString()+" done ";
        }
    }


    static class Scanner
    {
        StringTokenizer st;
        BufferedReader br;

        public Scanner(InputStream s){	br = new BufferedReader(new InputStreamReader(s));}

        public String next() throws IOException
        {
            while (st == null || !st.hasMoreTokens())
                st = new StringTokenizer(br.readLine());
            return st.nextToken();
        }

        public int nextInt() throws IOException {return Integer.parseInt(next());}

        public long nextLong() throws IOException {return Long.parseLong(next());}

        public String nextLine() throws IOException {return br.readLine();}

        public double nextDouble() throws IOException
        {
            String x = next();
            StringBuilder sb = new StringBuilder("0");
            double res = 0, f = 1;
            boolean dec = false, neg = false;
            int start = 0;
            if(x.charAt(0) == '-')
            {
                neg = true;
                start++;
            }
            for(int i = start; i < x.length(); i++)
                if(x.charAt(i) == '.')
                {
                    res = Long.parseLong(sb.toString());
                    sb = new StringBuilder("0");
                    dec = true;
                }
                else
                {
                    sb.append(x.charAt(i));
                    if(dec)
                        f *= 10;
                }
            res += Long.parseLong(sb.toString()) / f;
            return res * (neg?-1:1);
        }

        public boolean ready() throws IOException {return br.ready();}


    }
}
