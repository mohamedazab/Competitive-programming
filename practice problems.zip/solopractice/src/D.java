import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;


public class D {




	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		PrintWriter out=new PrintWriter(System.out);
		int n=sc.nextInt();
		int k=sc.nextInt();
		int c=1;
		int ans=1;
	
		FenwickTree ft=new FenwickTree(n);
		boolean yes[]=new boolean[n+1];
		while(!yes[c]){
			int nxt=c+k;
			int com=0;
			if(nxt>n){
				nxt-=n;
				
			}
			else
				ans+=ft.rsq(c, nxt);
			ft.update(c,1);
			ft.update(nxt, 1);
			yes[c]=true;
			c=nxt;
			System.out.println(ans);
			
			
			
		}
		
		
		
		}
	static 	class FenwickTree { 

			int n;
			int[] ft;
			
		public	FenwickTree(int size) { n = size; ft = new int[n+1]; }
			
			int rsq(int b) 
			{
				int sum = 0;
				while(b > 0) { sum += ft[b]; b -= b & -b;}	
				return sum;
			}
			
			int rsq(int a, int b) { return rsq(b) - rsq(a-1); }	
			
			void update(int k, int val)	
			{
				while(k <= n) { ft[k] += val; k += k & -k; }	
				
			}
			
			int point_query(int idx)	// c * O(log n), c < 1
			{
				int sum = ft[idx];
				if(idx > 0)
				{
					int z = idx ^ (idx & -idx);
					--idx;
					while(idx != z)
					{
						sum -= ft[idx];
						idx ^= idx & -idx;
					}
				}
				return sum;
			}
		}




	
	
	static class Scanner
	{
		StringTokenizer st;
		BufferedReader br;

		public Scanner(InputStream s){	br = new BufferedReader(new InputStreamReader(s));}

		public String next() throws IOException
		{
			while (st == null || !st.hasMoreTokens())
				st = new StringTokenizer(br.readLine());
			return st.nextToken();
		}

		public int nextInt() throws IOException {return Integer.parseInt(next());}

		public long nextLong() throws IOException {return Long.parseLong(next());}

		public String nextLine() throws IOException {return br.readLine();}

		public double nextDouble() throws IOException
		{
			String x = next();
			StringBuilder sb = new StringBuilder("0");
			double res = 0, f = 1;
			boolean dec = false, neg = false;
			int start = 0;
			if(x.charAt(0) == '-')
			{
				neg = true;
				start++;
			}
			for(int i = start; i < x.length(); i++)
				if(x.charAt(i) == '.')
				{
					res = Long.parseLong(sb.toString());
					sb = new StringBuilder("0");
					dec = true;
				}
				else
				{
					sb.append(x.charAt(i));
					if(dec)
						f *= 10;
				}
			res += Long.parseLong(sb.toString()) / f;
			return res * (neg?-1:1);
		}

		public boolean ready() throws IOException {return br.ready();}


	}
}
